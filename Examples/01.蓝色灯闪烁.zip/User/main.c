
#include	"test.h"


/*功能描述：执行 main 函数前的初始化函数
 *参数描述：无 
 *返回信息：无
 *注意事项：无
 *知识参考：无
 *修订记录：
 *Charlie @2019/01/31
 *  新建
 */
void	SystemInit(void)
{
}


/*功能描述：延时
 *参数描述：无 
 *返回信息：无
 *注意事项：无
 *知识参考：无
 *修订记录：
 *Charlie @2019/02/2
 *  新建
 */ 
void	Delay( volatile unsigned ms )
{
	for (; ms != 0; ms--);
}

/*功能描述：系统入口
 *参数描述：无 
 *返回信息：无
 *注意事项：无
 *知识参考：无
 *修订记录：
 *Charlie @2019/01/31
 *  新建
 */
int	main(void)
{
	Led_Initialize();
	while( 1 )
	{
		Led_On( 1 );
		Delay( 0x3FFFFF );
		Led_On( 0 );
		Delay( 0x3FFFFF );
	}
	return	0;
}
