#ifndef __TEST_H
#define __TEST_H

void    Led_Initialize( void );
void    Led_On( int on );

#endif
